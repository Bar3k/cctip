√Sebelum run scnya lakukan dulu command ini di termux

pip install -r req.txt

know your own risk

√Lalu perintah untuk menjalankannya

python cctipv1.py +62xxxxx

√Sekian... Salam kompak dan budayakan membaca